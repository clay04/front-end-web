class HeaderPage extends React.Component {
    render() {
        return (
            <h2>Cities</h2>
        );
    }
}