class FooterPage extends React.Component {
    render() {
        return (
            <p>Footer</p>
        );
    }
}