class NavbarPage extends React.Component {
    render() {
        return (
            <div class="navbar">
                <a href="#">Home</a>
                <a href="#">Project</a>
                <a href="#">Data</a>
                <a href="#" class="right">Help</a>
            </div>
        );
    }
}