class SidebarPage extends React.Component {
    render() {
        return (
            <div class="side">
                <h2>About Me</h2>
                <h5>My Photo:</h5>
                <div class="fakeimg" style={{height: "150px;"}}>Image</div>
                <p>Hi, my name is Semmy. I really love programming. I hope we can work together.</p>
            </div>
        );
    }
}