class FooterPage extends React.Component {
    render() {
        return (
            <div class="footer">
                <h2>Universitas Klabat</h2>
            </div>
        );
    }
}